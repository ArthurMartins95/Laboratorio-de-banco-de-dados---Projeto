
use lanhouse;

commit;
SELECT * FROM Cliente;


insert into Cliente
values (3221,'José', 'Brasil');

insert into Cliente
values (1223, 'Carlos', 'Mexico');

Select Funcionario.id_funcionario
FROM funcionario
Inner join Cliente
ON funcionario.id_funcionario = Funcionario.id_funcionario;
