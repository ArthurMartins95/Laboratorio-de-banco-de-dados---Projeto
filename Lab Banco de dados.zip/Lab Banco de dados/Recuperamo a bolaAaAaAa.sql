
use lanhouse;


DROP tables IF Exists Cliente;
DROP tables if exists Funcionario;
Drop tables if exists Atendimento;
Drop tables if exists Computador;
Drop tables if exists Pagamento;
Drop Tables if exists Impressora;
Drop Tables if exists Computador;

CREATE TABLE Cliente(
id_cliente INT PRIMARY KEY AUTO_INCREMENT NOT NULL,
nome_cliente VARCHAR(100) NOT NULL,
nacionalidade_cliente VARCHAR(50));

CREATE TABLE IF NOT exists Funcionario(
id_Funcionario INT  AUTO_INCREMENT PRIMARY KEY NOT NULL,
nome_Funcionario  VARCHAR(255) NOT NULL,
cargo_Funcionario VARCHAR(255) NOT NULL,
especialidade_Funcionario VARCHAR(100));


CREATE TABLE IF NOT exists Atendimento(
ID_Atendimento INT PRIMARY KEY AUTO_INCREMENT NOT NULL,
id_cliente INT,
data_Atendimento VARCHAR(100) NOT NULL,
horario_Atendimento VARCHAR(100) NOT NULL,
Status_Atendimento VARCHAR(50));


CREATE TABLE IF NOT Exists Computador(
ID_Computador INT PRIMARY KEY AUTO_INCREMENT NOT NULL,
data_Computador VARCHAR(100) NOT NULL,
Check_Computador VARCHAR(50));


CREATE TABLE IF NOT Exists Pagamento(
ID_Pagamento INT PRIMARY KEY AUTO_INCREMENT NOT NULL,
tempo_uso VARCHAR(100) NOT NULL,
recibo VARCHAR(10));


CREATE TABLE if not exists Impressora(
ID_Impressora INT PRIMARY KEY AUTO_INCREMENT NOT NULL,
Impressora_Status VARCHAR (100));


CREATE TABLE If not exists impressao(
ID_impressao INT PRIMARY KEY auto_increment not null,
ID_sessao INT,
ID_cliente INT,
ID_Computador INT,


foreign key (id_sessao) References sessao(ID),
foreign key (ID_cliente) References Cliente(ID),
foreign key (ID_Computador) References Computador(ID),


Quantidades_Documentos VARCHAR(100) NOT NULL,
Data_uso VARCHAR(10));


CREATE TABLE If not exists sessao(
ID_sessao INT auto_increment PRIMARY KEY NOT NULL, 
ID_cliente INT,
ID_Computador INT,
foreign key (ID_cliente) References Cliente(ID),
foreign key (ID_Computador) References Computador(ID)
);

